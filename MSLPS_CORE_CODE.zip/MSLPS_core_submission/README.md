# MSLPS core protocol code

This package contains the released core code accompanying the MSLPS manuscript. The complete control flow of Protocol 1 and Protocol 2 is retained so that the correspondence between the manuscript and the implementation can be inspected directly.

## Scope

- `mslps_core/protocol1.py` implements the complete preparation stage and Steps 1--6 of Protocol 1.
- `mslps_core/protocol2.py` implements the complete preparation stage and Steps 1--9 of Protocol 2, including the two encrypted calculation paths, the symmetric cut-and-choose procedure, removal of the two randomization factors, winner agreement, and the final Pedersen commitment opening.
- `mslps_core/commitment.py` contains the Pedersen commitment used for the randomized prime-to-position mapping.
- `mslps_core/encoding.py` contains coordinate-domain normalization, prime generation, factor counting, and the agreed tie-handling rule.
- `mslps_core/interfaces.py` defines the cryptographic operations required by the two protocols.
- `parameters.json` summarizes the main parameters reported in the manuscript; it is not an executable experiment configuration.

The concrete FHE-NTRU and NTRU primitive implementations, AIS data preparation, network transport, experiment drivers, timing code, and figure-generation scripts are not included in this partial public release. The protocol files therefore receive cryptographic backends through the interfaces in `interfaces.py`; no substitute cryptographic backend is embedded in the released protocol logic. The complete implementation is available from the corresponding author upon reasonable request.

For compactness, both parties are orchestrated in one process; controller-held variables represent party-local state and do not imply that those values are disclosed to the other party.

## Inputs and parameters

The protocol input consists of discrete two-dimensional coordinate sets. Coordinate conversion, grid construction, and trajectory sampling precede the protocol and are described in the manuscript. `ProtocolConfig` requires the coordinate-domain dimensions and the protocol parameters \(\kappa_1\), \(\kappa_2\), \(\mu\), \(M\), and \(M/2\). The caller must select them within the plaintext-space and decryption-correctness bounds stated in the manuscript.

Protocol 2 uses a deterministic, pre-agreed rule when several candidates have the same maximum score. The supplied configuration supports either the lowest or highest candidate index as that rule.

## Software requirement

The released source uses Python 3.11 or later. A concrete execution additionally requires compatible FHE-NTRU and verifiable NTRU backends implementing `HomomorphicBackend` and `VerifiableNtruBackend`.
