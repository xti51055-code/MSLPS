from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from random import Random
from secrets import SystemRandom
from typing import Iterable, Sequence


# RFC 3526, 2048-bit MODP group (group 14).
_MODP_2048 = int(
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
    "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
    "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
    "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
    "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
    "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
    "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
    "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
    "15728E5A8AACAA68FFFFFFFFFFFFFFFF",
    16,
)


def _hash_to_subgroup(label: bytes, modulus: int) -> int:
    counter = 0
    while True:
        digest = sha256(label + counter.to_bytes(4, "big")).digest()
        element = pow(int.from_bytes(digest, "big") % modulus, 2, modulus)
        if element not in (0, 1):
            return element
        counter += 1


@dataclass(frozen=True, slots=True)
class PedersenParameters:
    modulus: int
    order: int
    value_generator: int
    index_generator: int
    blinding_generator: int

    @classmethod
    def standard(cls) -> "PedersenParameters":
        modulus = _MODP_2048
        return cls(
            modulus=modulus,
            order=(modulus - 1) // 2,
            value_generator=_hash_to_subgroup(b"MSLPS/value", modulus),
            index_generator=_hash_to_subgroup(b"MSLPS/index", modulus),
            blinding_generator=_hash_to_subgroup(b"MSLPS/blinding", modulus),
        )


@dataclass(frozen=True, slots=True)
class CommitmentOpening:
    value: int
    index: int
    blinding: int


@dataclass(frozen=True, slots=True)
class CommittedValue:
    commitment: int
    opening: CommitmentOpening


class PedersenVectorCommitment:
    def __init__(
        self,
        parameters: PedersenParameters | None = None,
        rng: Random | SystemRandom | None = None,
    ) -> None:
        self.parameters = parameters or PedersenParameters.standard()
        self._rng = rng or SystemRandom()

    def commit(
        self,
        value: int,
        index: int,
        blinding: int | None = None,
    ) -> CommittedValue:
        self._validate_message(value, index)
        order = self.parameters.order
        randomizer = self._rng.randrange(1, order) if blinding is None else blinding
        if not 0 < randomizer < order:
            raise ValueError("blinding must be between 1 and the group order - 1")
        opening = CommitmentOpening(value, index, randomizer)
        return CommittedValue(self._evaluate(opening), opening)

    def commit_vector(self, values: Iterable[int]) -> tuple[CommittedValue, ...]:
        return tuple(self.commit(value, index) for index, value in enumerate(values))

    def verify(self, commitment: int, opening: CommitmentOpening) -> bool:
        if not isinstance(opening, CommitmentOpening):
            return False
        try:
            self._validate_message(opening.value, opening.index)
        except (TypeError, ValueError):
            return False
        if not 0 < opening.blinding < self.parameters.order:
            return False
        return commitment == self._evaluate(opening)

    def verify_vector(
        self,
        commitments: Sequence[int],
        openings: Sequence[CommitmentOpening],
    ) -> bool:
        return len(commitments) == len(openings) and all(
            self.verify(commitment, opening)
            for commitment, opening in zip(commitments, openings, strict=True)
        )

    def _evaluate(self, opening: CommitmentOpening) -> int:
        params = self.parameters
        return (
            pow(params.value_generator, opening.value, params.modulus)
            * pow(params.index_generator, opening.index, params.modulus)
            * pow(params.blinding_generator, opening.blinding, params.modulus)
        ) % params.modulus

    def _validate_message(self, value: int, index: int) -> None:
        order = self.parameters.order
        for name, item in (("value", value), ("index", index)):
            if isinstance(item, bool) or not isinstance(item, int):
                raise TypeError(f"{name} must be an integer")
            if not 0 <= item < order:
                raise ValueError(f"{name} must be between 0 and the group order - 1")
