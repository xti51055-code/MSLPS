from __future__ import annotations

from typing import Any, Protocol


Ciphertext = Any
PublicKey = Any
SecretKey = Any
NtruCiphertext = Any
NtruPublicKey = Any
NtruSecretKey = Any
NtruResponse = Any


class HomomorphicBackend(Protocol):
    def keygen(self) -> tuple[PublicKey, SecretKey]: ...

    def encrypt(self, value: int, public_key: PublicKey) -> Ciphertext: ...

    def decrypt(self, ciphertext: Ciphertext, secret_key: SecretKey) -> int: ...

    def multiply(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey,
    ) -> Ciphertext: ...

    def add(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey,
    ) -> Ciphertext: ...

    def subtract(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey,
    ) -> Ciphertext: ...


class VerifiableNtruBackend(Protocol):
    @property
    def max_message(self) -> int: ...

    def keygen(self) -> tuple[NtruPublicKey, NtruSecretKey]: ...

    def create_instance(
        self,
        value: int,
        public_key: NtruPublicKey,
    ) -> tuple[NtruCiphertext, NtruResponse]:
        """Create one verifiable NTRU instance for value."""
        ...

    def verify_response(
        self,
        ciphertext: NtruCiphertext,
        response: NtruResponse,
        public_key: NtruPublicKey,
    ) -> bool: ...

    def create_correction(
        self,
        noise_exponent: int,
        translation: int,
        public_key: NtruPublicKey,
    ) -> NtruCiphertext:
        """Encrypt translation - noise_exponent for the selected instance."""
        ...

    def add(
        self,
        left: NtruCiphertext,
        right: NtruCiphertext,
        public_key: NtruPublicKey,
    ) -> NtruCiphertext: ...

    def decrypt(
        self,
        ciphertext: NtruCiphertext,
        secret_key: NtruSecretKey,
    ) -> int: ...
