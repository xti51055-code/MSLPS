from __future__ import annotations

from dataclasses import dataclass
from math import isqrt
from typing import Iterable, Sequence

Point = tuple[int, int]


@dataclass(frozen=True, slots=True)
class CoordinateDomain:
    rows: int
    columns: int

    def __post_init__(self) -> None:
        if isinstance(self.rows, bool) or not isinstance(self.rows, int) or self.rows <= 0:
            raise ValueError("rows must be a positive integer")
        if isinstance(self.columns, bool) or not isinstance(self.columns, int) or self.columns <= 0:
            raise ValueError("columns must be a positive integer")

    @property
    def size(self) -> int:
        return self.rows * self.columns

    def normalize_points(self, points: Iterable[Sequence[int]]) -> tuple[Point, ...]:
        normalized: list[Point] = []
        seen: set[Point] = set()
        for point in points:
            if len(point) != 2:
                raise ValueError("each point must contain exactly two coordinates")
            row, column = point
            if isinstance(row, bool) or isinstance(column, bool):
                raise TypeError("point coordinates must be integers")
            if not isinstance(row, int) or not isinstance(column, int):
                raise TypeError("point coordinates must be integers")
            if not 0 <= row < self.rows or not 0 <= column < self.columns:
                raise ValueError(f"point {(row, column)} is outside the coordinate domain")
            normalized_point = (row, column)
            if normalized_point not in seen:
                normalized.append(normalized_point)
                seen.add(normalized_point)
        return tuple(normalized)

    def index(self, point: Sequence[int]) -> int:
        normalized = self.normalize_points((point,))
        row, column = normalized[0]
        return row * self.columns + column


def _is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value in (2, 3):
        return True
    if value % 2 == 0:
        return False
    limit = isqrt(value)
    divisor = 3
    while divisor <= limit:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def generate_primes(count: int, start: int = 3) -> tuple[int, ...]:
    if isinstance(count, bool) or not isinstance(count, int) or count < 0:
        raise ValueError("count must be a non-negative integer")
    if isinstance(start, bool) or not isinstance(start, int) or start < 2:
        raise ValueError("start must be an integer of at least 2")
    primes: list[int] = []
    candidate = start
    while len(primes) < count:
        if _is_prime(candidate):
            primes.append(candidate)
        candidate += 1
    return tuple(primes)


def factor_over_primes(value: int, primes: Sequence[int]) -> tuple[int, ...]:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError("value must be a positive integer")
    factors = tuple(primes)
    if len(set(factors)) != len(factors) or any(not _is_prime(item) for item in factors):
        raise ValueError("primes must contain distinct prime numbers")
    remaining = value
    counts: list[int] = []
    for prime in factors:
        exponent = 0
        while remaining % prime == 0:
            remaining //= prime
            exponent += 1
        counts.append(exponent)
    if remaining != 1:
        raise ValueError("value contains a factor outside the supplied prime set")
    return tuple(counts)


def argmax_index(values: Sequence[int], tie_rule: str = "lowest") -> int:
    if not values:
        raise ValueError("values cannot be empty")
    if tie_rule not in {"lowest", "highest"}:
        raise ValueError("tie_rule must be 'lowest' or 'highest'")
    maximum = max(values)
    matches = [index for index, value in enumerate(values) if value == maximum]
    return matches[0] if tie_rule == "lowest" else matches[-1]

