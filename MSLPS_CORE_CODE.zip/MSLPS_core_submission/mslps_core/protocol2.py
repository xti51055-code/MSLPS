from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from math import comb
from random import Random, SystemRandom
from typing import Iterable, Sequence

from .commitment import CommittedValue, PedersenVectorCommitment
from .config import ProtocolConfig
from .encoding import Point, argmax_index, factor_over_primes, generate_primes
from .interfaces import (
    Ciphertext,
    HomomorphicBackend,
    NtruPublicKey,
    NtruSecretKey,
    PublicKey,
    SecretKey,
    VerifiableNtruBackend,
)


@dataclass(frozen=True, slots=True)
class Protocol2Inputs:
    candidate_sets: tuple[tuple[Point, ...], ...]
    query_set: tuple[Point, ...]


@dataclass(frozen=True, slots=True)
class MaskedScoreComponent:
    component_id: int
    candidate_index: int | None
    assigned_prime: int
    masked_value: int
    noise_exponent: int


@dataclass(frozen=True, slots=True)
class CutAndChooseResult:
    scores: tuple[int, ...]
    translated_values: tuple[int, ...]
    translation: int
    audited_indices: tuple[int, ...]
    selected_index: int
    verified: bool


@dataclass(frozen=True, slots=True)
class H2Evaluation:
    components: tuple[MaskedScoreComponent, ...]
    permuted_primes: tuple[int, ...]
    assigned_primes: tuple[int, ...]
    candidate_positions: tuple[int, ...]
    commitments: tuple[CommittedValue, ...]


@dataclass(frozen=True, slots=True)
class Protocol2Result:
    winner_index: int
    selected_set: tuple[Point, ...]
    selected_prime: int
    opened_position: int
    commitment_verified: bool
    cut_and_choose_verified: bool

    @property
    def selected_index(self) -> int:
        return self.winner_index


def cut_and_choose_cheating_fraction(
    repetitions: int,
    forged_instances: int = 1,
    audit_count: int | None = None,
) -> Fraction:
    if isinstance(repetitions, bool) or not isinstance(repetitions, int):
        raise TypeError("repetitions must be an integer")
    if repetitions < 2:
        raise ValueError("repetitions must be at least 2")
    audits = repetitions // 2 if audit_count is None else audit_count
    if isinstance(audits, bool) or not isinstance(audits, int):
        raise TypeError("audit_count must be an integer")
    if not 1 <= audits < repetitions:
        raise ValueError("audit_count must be between 1 and repetitions - 1")
    if isinstance(forged_instances, bool) or not isinstance(forged_instances, int):
        raise TypeError("forged_instances must be an integer")
    if not 0 <= forged_instances <= repetitions:
        raise ValueError("forged_instances must be between 0 and repetitions")
    if forged_instances == 0 or repetitions - forged_instances < audits:
        return Fraction(0, 1)
    pass_probability = Fraction(
        comb(repetitions - forged_instances, audits),
        comb(repetitions, audits),
    )
    selection_probability = Fraction(
        forged_instances,
        repetitions - audits,
    )
    return pass_probability * selection_probability


def cut_and_choose_cheating_probability(
    repetitions: int,
    forged_instances: int = 1,
    audit_count: int | None = None,
) -> float:
    return float(
        cut_and_choose_cheating_fraction(
            repetitions,
            forged_instances,
            audit_count,
        )
    )


class CutAndChoose:
    def __init__(
        self,
        repetitions: int,
        audit_count: int,
        scheme: VerifiableNtruBackend,
        rng: Random | SystemRandom,
    ) -> None:
        cut_and_choose_cheating_fraction(repetitions, 0, audit_count)
        if repetitions % 2 or audit_count != repetitions // 2:
            raise ValueError("the protocol requires an M/2 challenge")
        self.repetitions = repetitions
        self.audit_count = audit_count
        self.scheme = scheme
        self.rng = rng

    def execute(
        self,
        components: Sequence[MaskedScoreComponent],
        public_key: NtruPublicKey,
        secret_key: NtruSecretKey,
        score_upper_bound: int,
    ) -> CutAndChooseResult:
        if not components:
            raise ValueError("cut-and-choose requires at least one component")
        if len({item.component_id for item in components}) != len(components):
            raise ValueError("component identifiers must be unique")
        if any(
            item.noise_exponent < 0
            or item.masked_value < item.noise_exponent
            for item in components
        ):
            raise ValueError("masked values must contain their noise exponents")

        batches = tuple(
            tuple(
                self.scheme.create_instance(item.masked_value, public_key)
                for item in components
            )
            for _ in range(self.repetitions)
        )
        audited = tuple(
            sorted(self.rng.sample(range(self.repetitions), self.audit_count))
        )
        unopened = tuple(
            index
            for index in range(self.repetitions)
            if index not in audited
        )
        selected = self.rng.choice(unopened)

        verified = all(
            self.scheme.verify_response(
                ciphertext,
                response,
                public_key,
            )
            for batch_index in audited
            for ciphertext, response in batches[batch_index]
        )
        if not verified:
            return CutAndChooseResult((), (), 0, audited, selected, False)

        lower_translation = max(item.noise_exponent for item in components)
        upper_translation = self.scheme.max_message - score_upper_bound
        if lower_translation > upper_translation:
            raise OverflowError("the NTRU plaintext space is too small")
        translation = self.rng.randint(lower_translation, upper_translation)

        scores: list[int] = []
        translated_values: list[int] = []
        for item, (ciphertext, _) in zip(
            components,
            batches[selected],
            strict=True,
        ):
            correction = self.scheme.create_correction(
                item.noise_exponent,
                translation,
                public_key,
            )
            corrected = self.scheme.add(ciphertext, correction, public_key)
            recovered = self.scheme.decrypt(corrected, secret_key)
            expected = item.masked_value + translation - item.noise_exponent
            if recovered != expected:
                raise ArithmeticError("the corrected NTRU value is inconsistent")
            translated_values.append(recovered)
            scores.append(recovered - translation)

        return CutAndChooseResult(
            scores=tuple(scores),
            translated_values=tuple(translated_values),
            translation=translation,
            audited_indices=audited,
            selected_index=selected,
            verified=True,
        )


class Protocol2:
    def __init__(
        self,
        config: ProtocolConfig,
        backend: HomomorphicBackend,
        verification_scheme: VerifiableNtruBackend,
        commitment: PedersenVectorCommitment,
    ) -> None:
        self.config = config
        self.backend = backend
        self.verification_scheme = verification_scheme
        self.commitment = commitment
        self._rng = SystemRandom()

    def normalize_inputs(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol2Inputs:
        candidates = tuple(
            self.config.domain.normalize_points(candidate_set)
            for candidate_set in candidate_sets
        )
        if not candidates:
            raise ValueError("candidate_sets cannot be empty")
        query = self.config.domain.normalize_points(query_set)
        if not query:
            raise ValueError("query_set cannot be empty")
        return Protocol2Inputs(candidates, query)

    def run(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol2Result:
        inputs = self.normalize_inputs(candidate_sets, query_set)
        candidate_count = len(inputs.candidate_sets)
        primes = generate_primes(
            candidate_count + self.config.auxiliary_prime_count,
            self.config.prime_start,
        )

        alice_he_public, alice_he_secret = self.backend.keygen()
        bob_he_public, bob_he_secret = self.backend.keygen()

        h1_components = self._evaluate_h1(
            inputs,
            primes,
            alice_he_public,
            alice_he_secret,
        )
        h2 = self._evaluate_h2(
            inputs,
            primes,
            bob_he_public,
            bob_he_secret,
        )

        alice_ntru_public, alice_ntru_secret = self.verification_scheme.keygen()
        bob_ntru_public, bob_ntru_secret = self.verification_scheme.keygen()
        verifier = CutAndChoose(
            self.config.cut_and_choose_instances,
            self.config.audit_count,
            self.verification_scheme,
            self._rng,
        )

        h1_result = verifier.execute(
            h1_components,
            alice_ntru_public,
            alice_ntru_secret,
            len(inputs.query_set),
        )
        h2_result = verifier.execute(
            h2.components,
            bob_ntru_public,
            bob_ntru_secret,
            min(
                len(inputs.query_set),
                max(len(item) for item in inputs.candidate_sets),
            ),
        )
        if not h1_result.verified or not h2_result.verified:
            raise ArithmeticError("cut-and-choose verification failed")

        h1_scores = h1_result.scores
        h2_scores = self._restore_candidate_order(h2.components, h2_result.scores)
        if h1_scores != h2_scores:
            raise ArithmeticError("the two encrypted calculation paths disagree")

        alice_winner = argmax_index(h1_scores, self.config.tie_rule)
        bob_winner = argmax_index(h2_scores, self.config.tie_rule)
        if alice_winner != bob_winner:
            raise ArithmeticError("Alice and Bob obtained different winners")

        selected_prime = primes[alice_winner]
        position_index = h2.permuted_primes.index(selected_prime)
        opened = h2.commitments[position_index]
        commitment_verified = (
            opened.opening.value == selected_prime
            and opened.opening.index == position_index + 1
            and self.commitment.verify(opened.commitment, opened.opening)
        )
        if not commitment_verified:
            raise ArithmeticError("the Pedersen commitment opening is invalid")

        return Protocol2Result(
            winner_index=alice_winner,
            selected_set=inputs.candidate_sets[alice_winner],
            selected_prime=selected_prime,
            opened_position=position_index + 1,
            commitment_verified=True,
            cut_and_choose_verified=True,
        )

    def _evaluate_h1(
        self,
        inputs: Protocol2Inputs,
        primes: Sequence[int],
        public_key: PublicKey,
        secret_key: SecretKey,
    ) -> tuple[MaskedScoreComponent, ...]:
        matrix = [1] * self.config.domain.size
        candidate_count = len(inputs.candidate_sets)
        for prime, candidate_set in zip(
            primes[:candidate_count],
            inputs.candidate_sets,
            strict=True,
        ):
            for point in candidate_set:
                matrix[self.config.domain.index(point)] *= prime

        encrypted_matrix = tuple(
            self.backend.encrypt(value, public_key) for value in matrix
        )
        selected_cells = tuple(
            encrypted_matrix[self.config.domain.index(point)]
            for point in inputs.query_set
        )
        aggregate = self._ciphertext_product(selected_cells, public_key)

        noise_primes = tuple(
            self._rng.choice(primes)
            for _ in range(self.config.h1_noise_factor_count)
        )
        noise_product = self._product(noise_primes)
        aggregate = self.backend.multiply(
            aggregate,
            self.backend.encrypt(noise_product, public_key),
            public_key,
        )

        masked_counts = factor_over_primes(
            self.backend.decrypt(aggregate, secret_key),
            primes,
        )
        noise_counts = factor_over_primes(noise_product, primes)
        residual = tuple(
            masked - noise
            for masked, noise in zip(masked_counts, noise_counts, strict=True)
        )
        if any(value < 0 for value in residual):
            raise ArithmeticError("the H1 noise exponents are inconsistent")
        if any(residual[candidate_count:]):
            raise ArithmeticError("an auxiliary H1 factor remains after correction")

        return tuple(
            MaskedScoreComponent(
                component_id=index,
                candidate_index=index,
                assigned_prime=primes[index],
                masked_value=masked_counts[index],
                noise_exponent=noise_counts[index],
            )
            for index in range(candidate_count)
        )

    def _evaluate_h2(
        self,
        inputs: Protocol2Inputs,
        primes: Sequence[int],
        public_key: PublicKey,
        secret_key: SecretKey,
    ) -> H2Evaluation:
        query = set(inputs.query_set)
        encrypted_membership = tuple(
            self.backend.encrypt(
                int((index // self.config.columns, index % self.config.columns) in query),
                public_key,
            )
            for index in range(self.config.domain.size)
        )

        permuted_primes = list(primes)
        self._rng.shuffle(permuted_primes)
        commitments = tuple(
            self.commitment.commit(prime, index + 1)
            for index, prime in enumerate(permuted_primes)
        )
        encrypted_permuted_primes = tuple(
            self.backend.encrypt(prime, public_key) for prime in permuted_primes
        )

        candidate_count = len(inputs.candidate_sets)
        candidate_positions = tuple(
            self._rng.sample(range(len(permuted_primes)), candidate_count)
        )
        assigned_primes = tuple(
            permuted_primes[position] for position in candidate_positions
        )
        assigned_prime_ciphertexts = tuple(
            encrypted_permuted_primes[position]
            for position in candidate_positions
        )

        one = self.backend.encrypt(1, public_key)
        masked_items: list[
            tuple[int | None, int, Ciphertext, tuple[int, ...]]
        ] = []
        for candidate_index, (candidate_set, assigned_prime, encrypted_prime) in enumerate(
            zip(
                inputs.candidate_sets,
                assigned_primes,
                assigned_prime_ciphertexts,
                strict=True,
            )
        ):
            encrypted_product = self.backend.encrypt(1, public_key)
            prime_minus_one = self.backend.subtract(encrypted_prime, one, public_key)
            for point in candidate_set:
                membership = encrypted_membership[self.config.domain.index(point)]
                selected_prime = self.backend.multiply(
                    membership,
                    prime_minus_one,
                    public_key,
                )
                encoded_factor = self.backend.add(selected_prime, one, public_key)
                encrypted_product = self.backend.multiply(
                    encrypted_product,
                    encoded_factor,
                    public_key,
                )
            masked_items.append(
                self._mask_h2_component(
                    candidate_index,
                    assigned_prime,
                    encrypted_product,
                    primes,
                    public_key,
                )
            )

        selected_positions = set(candidate_positions)
        for position, prime in enumerate(permuted_primes):
            if position in selected_positions:
                continue
            masked_items.append(
                self._mask_h2_component(
                    None,
                    prime,
                    self.backend.encrypt(1, public_key),
                    primes,
                    public_key,
                )
            )

        self._rng.shuffle(masked_items)
        components: list[MaskedScoreComponent] = []
        for component_id, item in enumerate(masked_items):
            candidate_index, assigned_prime, ciphertext, noise_primes = item
            factors = factor_over_primes(
                self.backend.decrypt(ciphertext, secret_key),
                primes,
            )
            noise_counts = factor_over_primes(
                self._product(noise_primes),
                primes,
            )
            residual = tuple(
                factor - noise
                for factor, noise in zip(factors, noise_counts, strict=True)
            )
            if any(value < 0 for value in residual):
                raise ArithmeticError("the H2 noise exponents are inconsistent")
            assigned_index = primes.index(assigned_prime)
            if any(
                value
                for index, value in enumerate(residual)
                if index != assigned_index
            ):
                raise ArithmeticError("an H2 component contains an unexpected factor")
            if candidate_index is None and residual[assigned_index] != 0:
                raise ArithmeticError("an auxiliary H2 component is not empty")
            components.append(
                MaskedScoreComponent(
                    component_id=component_id,
                    candidate_index=candidate_index,
                    assigned_prime=assigned_prime,
                    masked_value=factors[assigned_index],
                    noise_exponent=noise_counts[assigned_index],
                )
            )

        return H2Evaluation(
            components=tuple(components),
            permuted_primes=tuple(permuted_primes),
            assigned_primes=assigned_primes,
            candidate_positions=candidate_positions,
            commitments=commitments,
        )

    def _mask_h2_component(
        self,
        candidate_index: int | None,
        assigned_prime: int,
        ciphertext: Ciphertext,
        factor_base: Sequence[int],
        public_key: PublicKey,
    ) -> tuple[int | None, int, Ciphertext, tuple[int, ...]]:
        noise_primes = tuple(
            self._rng.choice(factor_base)
            for _ in range(self.config.h2_noise_factor_count)
        )
        encrypted_noise = self.backend.encrypt(
            self._product(noise_primes),
            public_key,
        )
        return (
            candidate_index,
            assigned_prime,
            self.backend.multiply(ciphertext, encrypted_noise, public_key),
            noise_primes,
        )

    def _restore_candidate_order(
        self,
        components: Sequence[MaskedScoreComponent],
        scores: Sequence[int],
    ) -> tuple[int, ...]:
        candidate_count = sum(
            item.candidate_index is not None for item in components
        )
        ordered: list[int | None] = [None] * candidate_count
        for item, score in zip(components, scores, strict=True):
            if item.candidate_index is None:
                if score != 0:
                    raise ArithmeticError("an auxiliary H2 component is not empty")
                continue
            ordered[item.candidate_index] = score
        if any(value is None for value in ordered):
            raise ArithmeticError("an H2 candidate component is missing")
        return tuple(int(value) for value in ordered)

    def _ciphertext_product(
        self,
        ciphertexts: Sequence[Ciphertext],
        public_key: PublicKey,
    ) -> Ciphertext:
        if not ciphertexts:
            return self.backend.encrypt(1, public_key)
        aggregate = ciphertexts[0]
        for ciphertext in ciphertexts[1:]:
            aggregate = self.backend.multiply(aggregate, ciphertext, public_key)
        return aggregate

    @staticmethod
    def _product(values: Iterable[int]) -> int:
        result = 1
        for value in values:
            result *= value
        return result
