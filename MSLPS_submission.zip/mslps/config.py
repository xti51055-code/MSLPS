from __future__ import annotations

from dataclasses import dataclass

from .encoding import CoordinateDomain


@dataclass(frozen=True, slots=True)
class ProtocolConfig:
    rows: int
    columns: int
    prime_start: int = 3
    noise_factor_count: int = 4
    global_mask_min: int = 1
    global_mask_max: int = 2**31 - 1
    tie_rule: str = "lowest"
    seed: int | None = None
    cut_and_choose_instances: int = 10
    audit_count: int = 5
    auxiliary_prime_count: int = 2

    def __post_init__(self) -> None:
        CoordinateDomain(self.rows, self.columns)
        if self.prime_start < 2:
            raise ValueError("prime_start must be at least 2")
        if self.noise_factor_count < 0:
            raise ValueError("noise_factor_count cannot be negative")
        if self.global_mask_min < 0:
            raise ValueError("global_mask_min cannot be negative")
        if self.global_mask_max < self.global_mask_min:
            raise ValueError("global_mask_max must not be smaller than global_mask_min")
        if self.tie_rule not in {"lowest", "highest"}:
            raise ValueError("tie_rule must be 'lowest' or 'highest'")
        if self.cut_and_choose_instances < 2:
            raise ValueError("cut_and_choose_instances must be at least 2")
        if not 1 <= self.audit_count < self.cut_and_choose_instances:
            raise ValueError(
                "audit_count must be smaller than cut_and_choose_instances"
            )
        if self.auxiliary_prime_count < 0:
            raise ValueError("auxiliary_prime_count cannot be negative")

    @property
    def domain(self) -> CoordinateDomain:
        return CoordinateDomain(self.rows, self.columns)


SubmissionConfig = ProtocolConfig

