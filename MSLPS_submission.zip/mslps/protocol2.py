from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, replace
from fractions import Fraction
from math import comb
from random import Random
from typing import Iterable, Sequence

from .commitment import CommitmentOpening, PedersenVectorCommitment
from .config import ProtocolConfig
from .encoding import CoordinateDomain, Point, argmax_index, factor_over_primes, generate_primes
from .he import Ciphertext, HomomorphicBackend, IntegerHomomorphicBackend, PublicKey


@dataclass(frozen=True, slots=True)
class Protocol2Inputs:
    candidate_sets: tuple[tuple[Point, ...], ...]
    query_set: tuple[Point, ...]


@dataclass(frozen=True, slots=True)
class CutAndChooseResult:
    values: tuple[int, ...]
    audited_indices: tuple[tuple[int, ...], ...]
    selected_indices: tuple[int, ...]
    verified: bool


@dataclass(frozen=True, slots=True)
class Protocol2Result:
    winner_index: int
    selected_set: tuple[Point, ...]
    scores: tuple[int, ...]
    h1_scores: tuple[int, ...]
    h2_scores: tuple[int, ...]
    selected_prime: int
    opened_position: int
    mapping_commitments: tuple[int, ...]
    commitment_verified: bool
    cut_and_choose_verified: bool
    audited_replicas: tuple[tuple[int, ...], ...]
    selected_replicas: tuple[int, ...]
    cheating_probability: float
    encrypted_cells: int
    h2_components: int

    @property
    def selected_index(self) -> int:
        return self.winner_index


def cut_and_choose_cheating_probability(
    repetitions: int,
    e: int = 1,
    audit_count: int | None = None,
) -> float:
    return float(
        cut_and_choose_cheating_fraction(repetitions, e, audit_count)
    )


def cut_and_choose_cheating_fraction(
    repetitions: int,
    e: int = 1,
    audit_count: int | None = None,
) -> Fraction:
    if isinstance(repetitions, bool) or not isinstance(repetitions, int) or repetitions < 2:
        raise ValueError("repetitions must be an integer of at least 2")
    audits = repetitions // 2 if audit_count is None else audit_count
    if isinstance(audits, bool) or not isinstance(audits, int):
        raise TypeError("audit_count must be an integer")
    if not 1 <= audits < repetitions:
        raise ValueError("audit_count must be between 1 and repetitions - 1")
    if isinstance(e, bool) or not isinstance(e, int):
        raise TypeError("e must be an integer")
    if not 0 <= e <= repetitions:
        raise ValueError("e must be between 0 and repetitions")
    if e == 0 or repetitions - e < audits:
        return Fraction(0, 1)
    escape = Fraction(comb(repetitions - e, audits), comb(repetitions, audits))
    selection = Fraction(e, repetitions - audits)
    return escape * selection


class CutAndChoose:
    def __init__(
        self,
        repetitions: int,
        audit_count: int,
        commitment: PedersenVectorCommitment,
        rng: Random,
    ) -> None:
        cut_and_choose_cheating_fraction(repetitions, 0, audit_count)
        self.repetitions = repetitions
        self.audit_count = audit_count
        self.commitment = commitment
        self.rng = rng

    def execute(self, values: Sequence[int]) -> CutAndChooseResult:
        outputs: list[int] = []
        audits: list[tuple[int, ...]] = []
        selections: list[int] = []
        verified = True

        for component, value in enumerate(values):
            replicas = tuple(
                self.commitment.commit(value, component * self.repetitions + index)
                for index in range(self.repetitions)
            )
            audited = tuple(sorted(self.rng.sample(range(self.repetitions), self.audit_count)))
            unopened = tuple(index for index in range(self.repetitions) if index not in audited)
            selected = self.rng.choice(unopened)

            for index in audited:
                replica = replicas[index]
                verified = verified and replica.opening.value == value
                verified = verified and self.commitment.verify(
                    replica.commitment,
                    replica.opening,
                )

            outputs.append(replicas[selected].opening.value)
            audits.append(audited)
            selections.append(selected)

        return CutAndChooseResult(tuple(outputs), tuple(audits), tuple(selections), verified)


class Protocol2:
    def __init__(
        self,
        config: ProtocolConfig,
        backend: HomomorphicBackend | None = None,
    ) -> None:
        self.config = config
        self.backend = backend or IntegerHomomorphicBackend()
        self._rng = Random(config.seed)
        self._commitment = PedersenVectorCommitment(rng=self._rng)

    def normalize_inputs(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol2Inputs:
        candidates = tuple(
            self.config.domain.normalize_points(candidate_set)
            for candidate_set in candidate_sets
        )
        if not candidates:
            raise ValueError("candidate_sets cannot be empty")
        query = self.config.domain.normalize_points(query_set)
        if not query:
            raise ValueError("query_set cannot be empty")
        return Protocol2Inputs(candidates, query)

    def run(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol2Result:
        inputs = self.normalize_inputs(candidate_sets, query_set)
        candidate_count = len(inputs.candidate_sets)
        primes = generate_primes(
            candidate_count + self.config.auxiliary_prime_count,
            self.config.prime_start,
        )

        h1_scores, encrypted_cells = self._evaluate_h1(inputs, primes)

        permuted_primes = list(primes)
        self._rng.shuffle(permuted_primes)
        mapping = self._commitment.commit_vector(permuted_primes)
        candidate_positions = tuple(
            self._rng.sample(range(len(permuted_primes)), candidate_count)
        )
        assigned_primes = tuple(permuted_primes[index] for index in candidate_positions)
        selected_positions = set(candidate_positions)
        auxiliary_primes = tuple(
            prime
            for index, prime in enumerate(permuted_primes)
            if index not in selected_positions
        )
        h2_scores, h2_components = self._evaluate_h2(
            inputs,
            assigned_primes,
            auxiliary_primes,
            primes,
        )

        if h1_scores != h2_scores:
            raise ArithmeticError("the H1 and H2 paths produced different match counts")

        cut_and_choose = CutAndChoose(
            self.config.cut_and_choose_instances,
            self.config.audit_count,
            self._commitment,
            self._rng,
        )
        h1_checked = cut_and_choose.execute(h1_scores)
        h2_checked = cut_and_choose.execute(h2_scores)
        cut_verified = h1_checked.verified and h2_checked.verified
        if not cut_verified or h1_checked.values != h2_checked.values:
            raise ArithmeticError("cut-and-choose verification failed")

        winner = argmax_index(h1_checked.values, self.config.tie_rule)
        opened_position = candidate_positions[winner]
        opened = mapping[opened_position]
        commitment_verified = self._commitment.verify(opened.commitment, opened.opening)
        commitment_verified = commitment_verified and opened.opening.value == assigned_primes[winner]
        commitment_verified = commitment_verified and opened.opening.index == opened_position
        if not commitment_verified:
            raise ArithmeticError("the prime-to-position commitment did not verify")

        probabilities = (
            cut_and_choose_cheating_probability(
                self.config.cut_and_choose_instances,
                e,
                self.config.audit_count,
            )
            for e in range(1, self.config.cut_and_choose_instances + 1)
        )
        audited = h1_checked.audited_indices + h2_checked.audited_indices
        selected = h1_checked.selected_indices + h2_checked.selected_indices
        return Protocol2Result(
            winner_index=winner,
            selected_set=inputs.candidate_sets[winner],
            scores=h1_checked.values,
            h1_scores=h1_scores,
            h2_scores=h2_scores,
            selected_prime=assigned_primes[winner],
            opened_position=opened_position,
            mapping_commitments=tuple(item.commitment for item in mapping),
            commitment_verified=commitment_verified,
            cut_and_choose_verified=cut_verified,
            audited_replicas=audited,
            selected_replicas=selected,
            cheating_probability=max(probabilities),
            encrypted_cells=encrypted_cells,
            h2_components=h2_components,
        )

    def _evaluate_h1(
        self,
        inputs: Protocol2Inputs,
        primes: Sequence[int],
    ) -> tuple[tuple[int, ...], int]:
        matrix = [1] * self.config.domain.size
        for prime, candidate_set in zip(primes, inputs.candidate_sets):
            for point in candidate_set:
                matrix[self.config.domain.index(point)] *= prime

        public_key, secret_key = self.backend.keygen()
        encrypted = tuple(self.backend.encrypt(value, public_key) for value in matrix)
        selected = tuple(
            encrypted[self.config.domain.index(point)]
            for point in inputs.query_set
        )
        aggregate = self._ciphertext_product(selected, public_key)

        noise_primes = tuple(
            self._rng.choice(primes)
            for _ in range(self.config.noise_factor_count)
        )
        noise_product = self._product(noise_primes)
        aggregate = self.backend.multiply_plain(aggregate, noise_product, public_key)
        blinded_counts = factor_over_primes(self.backend.decrypt(aggregate, secret_key), primes)
        noise_counts = factor_over_primes(noise_product, primes)
        scores = tuple(
            count - noise
            for count, noise in zip(blinded_counts[: len(inputs.candidate_sets)], noise_counts, strict=False)
        )
        return scores, len(encrypted)

    def _evaluate_h2(
        self,
        inputs: Protocol2Inputs,
        assigned_primes: Sequence[int],
        auxiliary_primes: Sequence[int],
        factor_base: Sequence[int],
    ) -> tuple[tuple[int, ...], int]:
        public_key, secret_key = self.backend.keygen()
        query = set(inputs.query_set)
        encrypted_membership = tuple(
            self.backend.encrypt(
                int((index // self.config.columns, index % self.config.columns) in query),
                public_key,
            )
            for index in range(self.config.domain.size)
        )

        components: list[tuple[int | None, int, Ciphertext, tuple[int, ...]]] = []
        for candidate_index, (prime, candidate_set) in enumerate(
            zip(assigned_primes, inputs.candidate_sets, strict=True)
        ):
            encrypted_product = self.backend.encrypt(1, public_key)
            for point in candidate_set:
                membership = encrypted_membership[self.config.domain.index(point)]
                encoded = self.backend.multiply_plain(membership, prime - 1, public_key)
                encoded = self.backend.add_plain(encoded, 1, public_key)
                encrypted_product = self.backend.multiply(
                    encrypted_product,
                    encoded,
                    public_key,
                )
            components.append(
                self._mask_h2_component(
                    candidate_index,
                    prime,
                    encrypted_product,
                    factor_base,
                    public_key,
                )
            )

        for prime in auxiliary_primes:
            components.append(
                self._mask_h2_component(
                    None,
                    prime,
                    self.backend.encrypt(1, public_key),
                    factor_base,
                    public_key,
                )
            )

        self._rng.shuffle(components)
        scores = [0] * len(inputs.candidate_sets)
        for candidate_index, assigned_prime, ciphertext, noise_primes in components:
            factors = factor_over_primes(self.backend.decrypt(ciphertext, secret_key), factor_base)
            noise = factor_over_primes(self._product(noise_primes), factor_base)
            denoised = tuple(
                count - mask
                for count, mask in zip(factors, noise, strict=True)
            )
            prime_position = factor_base.index(assigned_prime)
            if any(
                count
                for index, count in enumerate(denoised)
                if index != prime_position
            ):
                raise ArithmeticError("an H2 component contains an unexpected factor")
            score = denoised[prime_position]
            if candidate_index is None:
                if score != 0:
                    raise ArithmeticError("an auxiliary H2 component is not empty")
            else:
                scores[candidate_index] = score
        return tuple(scores), len(components)

    def _mask_h2_component(
        self,
        candidate_index: int | None,
        assigned_prime: int,
        ciphertext: Ciphertext,
        factor_base: Sequence[int],
        public_key: PublicKey,
    ) -> tuple[int | None, int, Ciphertext, tuple[int, ...]]:
        noise_primes = tuple(
            self._rng.choice(factor_base)
            for _ in range(self.config.noise_factor_count)
        )
        masked = self.backend.multiply_plain(
            ciphertext,
            self._product(noise_primes),
            public_key,
        )
        return candidate_index, assigned_prime, masked, noise_primes

    def _ciphertext_product(
        self,
        ciphertexts: Sequence[Ciphertext],
        public_key: PublicKey,
    ) -> Ciphertext:
        if not ciphertexts:
            return self.backend.encrypt(1, public_key)
        aggregate = ciphertexts[0]
        for ciphertext in ciphertexts[1:]:
            aggregate = self.backend.multiply(aggregate, ciphertext, public_key)
        return aggregate

    @staticmethod
    def _product(values: Iterable[int]) -> int:
        result = 1
        for value in values:
            result *= value
        return result


def run_protocol2(
    candidate_sets: Iterable[Iterable[Sequence[int]]],
    query_set: Iterable[Sequence[int]],
    *,
    config: ProtocolConfig | None = None,
    backend: HomomorphicBackend | None = None,
    domain: CoordinateDomain | None = None,
    repetitions: int | None = None,
    audit_count: int | None = None,
    padding: int | None = None,
    seed: int | None = None,
) -> Protocol2Result:
    candidates = tuple(tuple(point) for point in candidate_sets)
    query = tuple(query_set)
    if config is None:
        resolved_domain = domain or _infer_domain(candidates, query)
        config = ProtocolConfig(
            rows=resolved_domain.rows,
            columns=resolved_domain.columns,
            cut_and_choose_instances=10 if repetitions is None else repetitions,
            audit_count=5 if audit_count is None else audit_count,
            auxiliary_prime_count=2 if padding is None else padding,
            seed=seed,
        )
    else:
        changes: dict[str, object] = {}
        if domain is not None:
            changes.update(rows=domain.rows, columns=domain.columns)
        if repetitions is not None:
            changes["cut_and_choose_instances"] = repetitions
        if audit_count is not None:
            changes["audit_count"] = audit_count
        if padding is not None:
            changes["auxiliary_prime_count"] = padding
        if seed is not None:
            changes["seed"] = seed
        if changes:
            config = replace(config, **changes)
    return Protocol2(config, backend).run(candidates, query)


def _infer_domain(
    candidate_sets: Sequence[Sequence[Sequence[int]]],
    query_set: Sequence[Sequence[int]],
) -> CoordinateDomain:
    points = [point for candidate_set in candidate_sets for point in candidate_set]
    points.extend(query_set)
    if not points:
        raise ValueError("cannot infer a coordinate domain from empty inputs")
    if any(len(point) != 2 for point in points):
        raise ValueError("each point must contain exactly two coordinates")
    rows = max(point[0] for point in points) + 1
    columns = max(point[1] for point in points) + 1
    return CoordinateDomain(rows, columns)
