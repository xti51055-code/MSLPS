from __future__ import annotations

from dataclasses import dataclass
from random import Random
from typing import Iterable, Sequence

from .config import ProtocolConfig
from .encoding import Point, argmax_index, factor_over_primes, generate_primes
from .he import Ciphertext, HomomorphicBackend, IntegerHomomorphicBackend


@dataclass(frozen=True, slots=True)
class Protocol1Inputs:
    candidate_sets: tuple[tuple[Point, ...], ...]
    query_set: tuple[Point, ...]


@dataclass(frozen=True, slots=True)
class Protocol1Result:
    selected_index: int
    selected_set: tuple[Point, ...]
    selected_prime: int
    encrypted_cells: int
    homomorphic_multiplications: int


class Protocol1:
    def __init__(
        self,
        config: ProtocolConfig,
        backend: HomomorphicBackend | None = None,
    ) -> None:
        self.config = config
        self.backend = backend or IntegerHomomorphicBackend()
        self._rng = Random(config.seed)

    def normalize_inputs(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol1Inputs:
        candidates = tuple(
            self.config.domain.normalize_points(candidate_set)
            for candidate_set in candidate_sets
        )
        if not candidates:
            raise ValueError("candidate_sets cannot be empty")
        query = self.config.domain.normalize_points(query_set)
        if not query:
            raise ValueError("query_set cannot be empty")
        return Protocol1Inputs(candidates, query)

    def run(
        self,
        candidate_sets: Iterable[Iterable[Sequence[int]]],
        query_set: Iterable[Sequence[int]],
    ) -> Protocol1Result:
        inputs = self.normalize_inputs(candidate_sets, query_set)
        primes = generate_primes(len(inputs.candidate_sets), self.config.prime_start)
        matrix = [1] * self.config.domain.size

        for prime, candidate_set in zip(primes, inputs.candidate_sets, strict=True):
            for point in candidate_set:
                index = self.config.domain.index(point)
                matrix[index] *= prime

        public_key, secret_key = self.backend.keygen()
        encrypted_matrix = tuple(self.backend.encrypt(value, public_key) for value in matrix)

        selected_ciphertexts = [
            encrypted_matrix[self.config.domain.index(point)]
            for point in inputs.query_set
        ]
        aggregate = self._ciphertext_product(selected_ciphertexts, public_key)

        noise_primes = [
            self._rng.choice(primes)
            for _ in range(self.config.noise_factor_count)
        ]
        noise_product = 1
        for prime in noise_primes:
            noise_product *= prime
        aggregate = self.backend.multiply_plain(aggregate, noise_product, public_key)

        blinded_product = self.backend.decrypt(aggregate, secret_key)
        blinded_counts = factor_over_primes(blinded_product, primes)
        noise_counts = factor_over_primes(noise_product, primes)
        global_mask = self._rng.randint(
            self.config.global_mask_min,
            self.config.global_mask_max,
        )
        alice_message = tuple(count + global_mask for count in blinded_counts)
        bob_values = tuple(
            value - noise_count
            for value, noise_count in zip(alice_message, noise_counts, strict=True)
        )
        selected_index = argmax_index(bob_values, self.config.tie_rule)

        multiplications = max(0, len(selected_ciphertexts) - 1) + 1
        return Protocol1Result(
            selected_index=selected_index,
            selected_set=inputs.candidate_sets[selected_index],
            selected_prime=primes[selected_index],
            encrypted_cells=len(encrypted_matrix),
            homomorphic_multiplications=multiplications,
        )

    def _ciphertext_product(
        self,
        ciphertexts: Sequence[Ciphertext],
        public_key,
    ) -> Ciphertext:
        if not ciphertexts:
            return self.backend.encrypt(1, public_key)
        aggregate = ciphertexts[0]
        for ciphertext in ciphertexts[1:]:
            aggregate = self.backend.multiply(aggregate, ciphertext, public_key)
        return aggregate

