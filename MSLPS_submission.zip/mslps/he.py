from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from secrets import token_hex


@dataclass(frozen=True, slots=True)
class PublicKey:
    key_id: str
    modulus: int | None = None


@dataclass(frozen=True, slots=True)
class SecretKey:
    key_id: str
    modulus: int | None = None


@dataclass(frozen=True, slots=True)
class Ciphertext:
    value: int
    key_id: str
    depth: int = 0


class HomomorphicBackend(ABC):
    @abstractmethod
    def keygen(self) -> tuple[PublicKey, SecretKey]:
        ...

    @abstractmethod
    def encrypt(self, value: int, public_key: PublicKey) -> Ciphertext:
        ...

    @abstractmethod
    def decrypt(self, ciphertext: Ciphertext, secret_key: SecretKey) -> int:
        ...

    @abstractmethod
    def multiply(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        ...

    @abstractmethod
    def multiply_plain(
        self,
        ciphertext: Ciphertext,
        value: int,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        ...

    @abstractmethod
    def add(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        ...

    @abstractmethod
    def add_plain(
        self,
        ciphertext: Ciphertext,
        value: int,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        ...


class IntegerHomomorphicBackend(HomomorphicBackend):
    """Exact-integer backend for protocol execution and testing."""

    def __init__(self, modulus: int | None = None) -> None:
        if modulus is not None and (isinstance(modulus, bool) or not isinstance(modulus, int) or modulus <= 1):
            raise ValueError("modulus must be an integer greater than 1")
        self.modulus = modulus

    def _reduce(self, value: int) -> int:
        return value if self.modulus is None else value % self.modulus

    @staticmethod
    def _require_integer(value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("plaintext values must be non-negative integers")

    def keygen(self) -> tuple[PublicKey, SecretKey]:
        key_id = token_hex(16)
        return PublicKey(key_id, self.modulus), SecretKey(key_id, self.modulus)

    def encrypt(self, value: int, public_key: PublicKey) -> Ciphertext:
        self._require_integer(value)
        if public_key.modulus != self.modulus:
            raise ValueError("public key does not belong to this backend")
        return Ciphertext(self._reduce(value), public_key.key_id)

    def decrypt(self, ciphertext: Ciphertext, secret_key: SecretKey) -> int:
        if ciphertext.key_id != secret_key.key_id or secret_key.modulus != self.modulus:
            raise ValueError("ciphertext and secret key do not match")
        return self._reduce(ciphertext.value)

    def multiply(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        if left.key_id != right.key_id:
            raise ValueError("ciphertexts were created under different keys")
        if public_key is not None and public_key.key_id != left.key_id:
            raise ValueError("ciphertexts and public key do not match")
        value = self._reduce(left.value * right.value)
        return Ciphertext(value, left.key_id, max(left.depth, right.depth) + 1)

    def multiply_plain(
        self,
        ciphertext: Ciphertext,
        value: int,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        self._require_integer(value)
        if public_key is not None and public_key.key_id != ciphertext.key_id:
            raise ValueError("ciphertext and public key do not match")
        return Ciphertext(
            self._reduce(ciphertext.value * value),
            ciphertext.key_id,
            ciphertext.depth + 1,
        )

    def add(
        self,
        left: Ciphertext,
        right: Ciphertext,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        if left.key_id != right.key_id:
            raise ValueError("ciphertexts were created under different keys")
        if public_key is not None and public_key.key_id != left.key_id:
            raise ValueError("ciphertexts and public key do not match")
        value = self._reduce(left.value + right.value)
        return Ciphertext(value, left.key_id, max(left.depth, right.depth))

    def add_plain(
        self,
        ciphertext: Ciphertext,
        value: int,
        public_key: PublicKey | None = None,
    ) -> Ciphertext:
        self._require_integer(value)
        if public_key is not None and public_key.key_id != ciphertext.key_id:
            raise ValueError("ciphertext and public key do not match")
        return Ciphertext(
            self._reduce(ciphertext.value + value),
            ciphertext.key_id,
            ciphertext.depth,
        )

