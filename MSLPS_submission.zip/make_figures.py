from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def load_results(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def save_score_figure(results: dict, output_dir: Path) -> None:
    records = [
        (name, value)
        for name, value in (("Protocol 1", results.get("protocol1")), ("Protocol 2", results.get("protocol2")))
        if value is not None
    ]
    if not records:
        return

    figure, axis = plt.subplots(figsize=(6.4, 4.0))
    for name, record in records:
        scores = np.asarray(record["scores"], dtype=float)
        axis.plot(np.arange(1, len(scores) + 1), scores, marker="o", label=name)
    axis.set_xlabel("Candidate location-point set")
    axis.set_ylabel("Matching score")
    axis.legend(frameon=False)
    axis.grid(alpha=0.2)
    figure.tight_layout()
    figure.savefig(output_dir / "matching_scores.png", dpi=300)
    figure.savefig(output_dir / "matching_scores.pdf")
    plt.close(figure)


def save_time_figure(results: dict, output_dir: Path) -> None:
    records = [
        (name, value)
        for name, value in (("Protocol 1", results.get("protocol1")), ("Protocol 2", results.get("protocol2")))
        if value is not None
    ]
    if not records:
        return

    labels = [name for name, _ in records]
    times = [record["mean_execution_time_seconds"] for _, record in records]
    errors = [record.get("execution_time_sd_seconds", 0.0) for _, record in records]
    figure, axis = plt.subplots(figsize=(5.2, 3.8))
    axis.bar(
        labels,
        times,
        yerr=errors,
        capsize=4,
        color=("#d95f8d", "#d7301f")[: len(labels)],
    )
    axis.set_ylabel("Execution time (s)")
    axis.grid(axis="y", alpha=0.2)
    figure.tight_layout()
    figure.savefig(output_dir / "execution_time.png", dpi=300)
    figure.savefig(output_dir / "execution_time.pdf")
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("outputs/results.json"))
    parser.add_argument("--output", type=Path, default=Path("outputs/figures"))
    args = parser.parse_args()

    results = load_results(args.input)
    args.output.mkdir(parents=True, exist_ok=True)
    save_score_figure(results, args.output)
    save_time_figure(results, args.output)


if __name__ == "__main__":
    main()
