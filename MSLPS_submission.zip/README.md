# MSLPS protocol implementation

This package contains executable implementations of Protocol 1 and Protocol 2, including coordinate encoding, prime-product scoring, homomorphic operations, Pedersen commitment verification, cut-and-choose verification, result selection, tests, and figure generation.

## Installation

Python 3.10 or later is recommended.

```bash
python -m venv .venv
python -m pip install -r requirements.txt
```

## Configuration

The default experiment settings are stored in `config.json`. Input sets may be supplied through `data.input_file`; when it is `null`, `run_all.py` creates the reproducible task instance specified by `data` and `random_seed`.

An example external input is provided in `examples/input.json`.

Each external input file must be JSON with the following structure:

```json
{
  "alice_sets": [[[0, 0], [1, 2]], [[2, 1], [3, 4]]],
  "bob_query": [[0, 0], [1, 2]]
}
```

The default `IntegerHomomorphicBackend` provides an executable end-to-end backend and can be replaced through the same homomorphic-backend interface.

## Run

Run both protocols and save their outputs:

```bash
python run_all.py --config config.json
```

Run both protocols with an external input file:

```bash
python run_all.py --config config.json --input examples/input.json
```

Run one protocol only:

```bash
python run_all.py --config config.json --protocol protocol1
python run_all.py --config config.json --protocol protocol2
```

Generate figures from the saved results:

```bash
python make_figures.py --input outputs/results.json --output outputs/figures
```

Run the verification tests:

```bash
python -m unittest discover -s tests -v
```

## Source layout

- `mslps/he.py`: homomorphic-operation interface and executable integer backend.
- `mslps/encoding.py`: coordinate and prime-product encoding.
- `mslps/protocol1.py`: Protocol 1.
- `mslps/commitment.py`: Pedersen commitment.
- `mslps/protocol2.py`: Protocol 2 and cut-and-choose verification.
- `run_all.py`: experiment entry point.
- `make_figures.py`: result visualization.
- `tests/`: correctness and verification tests.

## Outputs

`run_all.py` writes `outputs/results.json`, containing the configuration, per-protocol scores, selected candidate, verification status, and execution-time statistics. Set `experiments.repetitions` to the required number of repeated runs. `make_figures.py` writes the corresponding figures to `outputs/figures`.

