from __future__ import annotations

from random import Random
from unittest import TestCase

from mslps.commitment import CommitmentOpening, PedersenVectorCommitment
from mslps.config import ProtocolConfig
from mslps.encoding import CoordinateDomain
from mslps.he import IntegerHomomorphicBackend
from mslps.protocol1 import Protocol1
from mslps.protocol2 import cut_and_choose_cheating_probability, run_protocol2


class ProtocolTests(TestCase):
    def setUp(self) -> None:
        self.candidates = [
            [(0, 0), (0, 1), (1, 1), (4, 4)],
            [(0, 0), (0, 1), (3, 3), (4, 3)],
            [(2, 2), (3, 3), (4, 4), (4, 3)],
        ]
        self.query = [(0, 0), (0, 1), (1, 1)]

    def test_integer_backend_preserves_homomorphic_product(self) -> None:
        backend = IntegerHomomorphicBackend()
        public_key, secret_key = backend.keygen()
        left = backend.encrypt(12, public_key)
        right = backend.encrypt(35, public_key)
        product = backend.multiply(left, right, public_key)
        product = backend.multiply_plain(product, 7, public_key)
        self.assertEqual(backend.decrypt(product, secret_key), 12 * 35 * 7)

    def test_pedersen_opening_detects_modified_value(self) -> None:
        commitment = PedersenVectorCommitment(rng=Random(7))
        committed = commitment.commit(value=29, index=4)
        self.assertTrue(commitment.verify(committed.commitment, committed.opening))
        modified = CommitmentOpening(31, committed.opening.index, committed.opening.blinding)
        self.assertFalse(commitment.verify(committed.commitment, modified))

    def test_protocol1_selects_largest_intersection(self) -> None:
        config = ProtocolConfig(
            rows=5,
            columns=5,
            noise_factor_count=3,
            global_mask_min=17,
            global_mask_max=17,
            seed=11,
            cut_and_choose_instances=4,
            audit_count=2,
        )
        result = Protocol1(config).run(self.candidates, self.query)
        self.assertEqual(result.selected_index, 0)
        self.assertEqual(result.selected_set, tuple(self.candidates[0]))

    def test_protocol2_verifies_and_selects_largest_intersection(self) -> None:
        result = run_protocol2(
            self.candidates,
            self.query,
            domain=CoordinateDomain(5, 5),
            repetitions=4,
            audit_count=2,
            seed=19,
        )
        self.assertEqual(result.winner_index, 0)
        self.assertTrue(result.commitment_verified)
        self.assertTrue(result.cut_and_choose_verified)

    def test_cut_and_choose_bound_matches_single_forgery_case(self) -> None:
        probability = cut_and_choose_cheating_probability(
            repetitions=10,
            e=1,
            audit_count=5,
        )
        self.assertAlmostEqual(probability, 0.1)
