from __future__ import annotations

import argparse
import json
import random
from dataclasses import asdict, is_dataclass, replace
from pathlib import Path
from statistics import mean, stdev
from time import perf_counter
from typing import Any

from mslps.config import ProtocolConfig
from mslps.protocol1 import Protocol1
from mslps.protocol2 import run_protocol2


def load_configuration(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_or_create_inputs(configuration: dict[str, Any], base_dir: Path) -> tuple[list, list]:
    data = configuration["data"]
    if data.get("input_file"):
        input_path = Path(data["input_file"])
        if not input_path.is_absolute():
            input_path = base_dir / input_path
        with input_path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload["alice_sets"], payload["bob_query"]

    rng = random.Random(configuration["random_seed"])
    rows = int(data["coordinate_rows"])
    columns = int(data["coordinate_columns"])
    set_count = int(data["candidate_set_count"])
    set_size = int(data["points_per_candidate"])
    query_size = int(data["query_point_count"])
    universe = [(row, column) for row in range(rows) for column in range(columns)]
    if max(set_size, query_size) > len(universe):
        raise ValueError("requested point-set size exceeds the coordinate domain")

    query = rng.sample(universe, query_size)
    query_pool = set(query)
    remaining = [point for point in universe if point not in query_pool]
    candidates = []
    for index in range(set_count):
        overlap = round(query_size * (set_count - index) / set_count)
        overlap = min(overlap, set_size, query_size)
        selected = rng.sample(query, overlap)
        selected.extend(rng.sample(remaining, set_size - overlap))
        rng.shuffle(selected)
        candidates.append(selected)
    return candidates, query


def build_protocol_config(configuration: dict[str, Any]) -> ProtocolConfig:
    data = configuration["data"]
    protocol = configuration["protocol"]
    global_mask = int(protocol["global_mask"])
    return ProtocolConfig(
        rows=int(data["coordinate_rows"]),
        columns=int(data["coordinate_columns"]),
        prime_start=int(protocol["prime_start"]),
        noise_factor_count=int(protocol["noise_factors"]),
        global_mask_min=global_mask,
        global_mask_max=global_mask,
        tie_rule=str(protocol["tie_rule"]),
        seed=int(configuration["random_seed"]),
        cut_and_choose_instances=int(protocol["cut_and_choose_instances"]),
        audit_count=int(protocol["audit_count"]),
        auxiliary_prime_count=int(protocol["padding_sets"]),
    )


def reference_scores(candidate_sets: list, query_set: list) -> list[int]:
    query = {tuple(point) for point in query_set}
    return [len({tuple(point) for point in candidate} & query) for candidate in candidate_sets]


def to_json_value(value: Any) -> Any:
    if is_dataclass(value):
        return to_json_value(asdict(value))
    if isinstance(value, dict):
        return {str(key): to_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_json_value(item) for item in value]
    return value


def execute(configuration: dict[str, Any], base_dir: Path, selection: str) -> dict[str, Any]:
    candidate_sets, query_set = load_or_create_inputs(configuration, base_dir)
    protocol_config = build_protocol_config(configuration)
    scores = reference_scores(candidate_sets, query_set)
    repetitions = int(configuration["experiments"].get("repetitions", 1))
    if repetitions < 1:
        raise ValueError("experiments.repetitions must be positive")
    results: dict[str, Any] = {
        "configuration": configuration,
        "input_summary": {
            "candidate_set_count": len(candidate_sets),
            "candidate_set_sizes": [len(item) for item in candidate_sets],
            "query_set_size": len(query_set),
        },
    }

    if selection in {"all", "protocol1"}:
        timings: list[float] = []
        result = None
        for repetition in range(repetitions):
            current = replace(protocol_config, seed=protocol_config.seed + repetition)
            start = perf_counter()
            result = Protocol1(current).run(candidate_sets, query_set)
            timings.append(perf_counter() - start)
        assert result is not None
        record = to_json_value(result)
        record.update(
            winner_index=result.selected_index,
            scores=scores,
            repetitions=repetitions,
            mean_execution_time_seconds=mean(timings),
            execution_time_sd_seconds=stdev(timings) if repetitions > 1 else 0.0,
        )
        results["protocol1"] = record

    if selection in {"all", "protocol2"}:
        timings = []
        result = None
        for repetition in range(repetitions):
            current = replace(protocol_config, seed=protocol_config.seed + repetition)
            start = perf_counter()
            result = run_protocol2(
                candidate_sets,
                query_set,
                config=current,
            )
            timings.append(perf_counter() - start)
        assert result is not None
        record = to_json_value(result)
        record.pop("mapping_commitments", None)
        record.pop("audited_replicas", None)
        record.pop("selected_replicas", None)
        record.update(
            winner_index=result.winner_index,
            scores=scores,
            repetitions=repetitions,
            mean_execution_time_seconds=mean(timings),
            execution_time_sd_seconds=stdev(timings) if repetitions > 1 else 0.0,
        )
        results["protocol2"] = record

    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("config.json"))
    parser.add_argument("--input", type=Path)
    parser.add_argument("--protocol", choices=("all", "protocol1", "protocol2"), default="all")
    args = parser.parse_args()

    config_path = args.config.resolve()
    configuration = load_configuration(config_path)
    if args.input is not None:
        configuration["data"]["input_file"] = str(args.input.resolve())
    results = execute(configuration, config_path.parent, args.protocol)
    output_path = Path(configuration["experiments"]["output_file"])
    if not output_path.is_absolute():
        output_path = config_path.parent / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(results, handle, ensure_ascii=False, indent=2)
    print(output_path)


if __name__ == "__main__":
    main()
